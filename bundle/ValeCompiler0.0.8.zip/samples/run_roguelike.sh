python3.8 ../valec.py --gen-heap --region-override resilient-v2 roguelike.vale ../vstl/generics/arrayutils.vale ../vstl/genericvirtuals/hashmap.vale ../vstl/genericvirtuals/opt.vale ../vstl/utils.vale ../vstl/castutils.vale ../vstl/printutils.vale ../vstl/genericvirtuals/optingarraylist.vale
./a.out
