Vale Compiler, version 0.0.8
http://vale.dev/

To run a program:
  python3.8 ../valec.py (vale files here)
  ./a.out

See samples/run_roguelike.sh for an example.

To run benchmarks:
  cd benchmarks
  ./run_benchmark.sh

